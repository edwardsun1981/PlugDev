将目录 
Local
拷贝至 
C:\Users\%UserName%\AppData 
目录下
vs 属性管理器中 会出现 配置
Microsoft.Cpp.ARM.user
Microsoft.Cpp.ARM64.user
Microsoft.Cpp.Win32.user
Microsoft.Cpp.x64.user